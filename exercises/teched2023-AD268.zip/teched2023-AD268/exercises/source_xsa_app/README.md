# Teched XSA-CF Example

1. MBT Build and Deploy into CF
2. Create Role templates and add to the use in BTP Cockpit
3. Test the Application