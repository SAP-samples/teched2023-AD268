sap.ui.controller("view.main", {

	onInit: function() {
	
	}
});